"use strict";
var __asyncValues = (this && this.__asyncValues) || function (o) {
    if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
    var m = o[Symbol.asyncIterator], i;
    return m ? m.call(o) : (o = typeof __values === "function" ? __values(o) : o[Symbol.iterator](), i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () { return this; }, i);
    function verb(n) { i[n] = o[n] && function (v) { return new Promise(function (resolve, reject) { v = o[n](v), settle(resolve, reject, v.done, v.value); }); }; }
    function settle(resolve, reject, d, v) { Promise.resolve(v).then(function(v) { resolve({ value: v, done: d }); }, reject); }
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const https_1 = __importDefault(require("https"));
const aws_sdk_1 = __importDefault(require("aws-sdk"));
const fs_1 = __importDefault(require("fs"));
aws_sdk_1.default.config.region = 'ap-south-1';
const sqs = new aws_sdk_1.default.SQS();
exports.getFirebaseData = async (event) => {
    var e_1, _a, e_2, _b;
    try {
        console.log(event);
        let story = '';
        let type = '';
        if (event.type === 'ask') {
            story = 'askstories';
            type = 'Ask HN';
        }
        else if (event.type === 'show') {
            story = 'showstories';
            type = 'Show HN';
        }
        else if (event.type === 'job') {
            story = 'jobstories';
            type = 'Jobs';
        }
        else {
            story = 'topstories';
            type = 'Top Stories';
        }
        const askStoriesData = await getData(`https://hacker-news.firebaseio.com/v0/${story}.json`);
        // console.log(askStoriesData)
        const stories = [];
        try {
            for (var _c = __asyncValues(askStoriesData.slice(0, 10)), _d; _d = await _c.next(), !_d.done;) {
                const storyId = _d.value;
                const storyData = await getData(`https://hacker-news.firebaseio.com/v0/item/${storyId}.json?print=pretty`);
                const date = new Date(1970, 0, 1);
                date.setSeconds(storyData.time);
                storyData.time = date.toISOString().replace('T', ' ').replace('Z', '');
                if (storyData.kids) {
                    const kids = [];
                    try {
                        for (var _e = __asyncValues(storyData.kids.slice(0, 3)), _f; _f = await _e.next(), !_f.done;) {
                            const kidId = _f.value;
                            const kidData = getData(`https://hacker-news.firebaseio.com/v0/item/${kidId}.json?print=pretty`).then(kid => {
                                if (kid && !kid.deleted && kid.time) {
                                    const kidDate = new Date(1970, 0, 1);
                                    kidDate.setSeconds(kid.time);
                                    kid.time = kidDate.toISOString().replace('T', ' ').replace('Z', '');
                                    return kid;
                                }
                            }).catch(error => console.log(error));
                            kids.push(kidData);
                        }
                    }
                    catch (e_2_1) { e_2 = { error: e_2_1 }; }
                    finally {
                        try {
                            if (_f && !_f.done && (_b = _e.return)) await _b.call(_e);
                        }
                        finally { if (e_2) throw e_2.error; }
                    }
                    storyData.kidData = await Promise.all(kids);
                }
                stories.push(storyData);
            }
        }
        catch (e_1_1) { e_1 = { error: e_1_1 }; }
        finally {
            try {
                if (_d && !_d.done && (_a = _c.return)) await _a.call(_c);
            }
            finally { if (e_1) throw e_1.error; }
        }
        const storiesInHtml = stories.map(story => {
            const text = story.text || '';
            return `
            <h1>
                ${story.url ?
                `<a href="${story.url}" target="_blank">${story.title}</a>` : `${story.title}`}
            </h1>
            <p> At ${story.time}
            <p> By <a href="https://news.ycombinator.com/user?id=${story.by}" target="_blank">${story.by}</a>
            <p> ${text}
            
            ${story.kidData ? `<h2>Comments</h2>` : ''}
            ${story.kidData && story.kidData.filter((kid) => kid).map((kid) => {
                const length = kid.text.indexOf('<p>') === -1 ? 20 : Math.max(50, kid.text.indexOf('<p>'));
                return `  
                <div class="commentBox">
                <p> At ${kid.time}
                <p> By <a href="https://news.ycombinator.com/user?id=${kid.by}" target="_blank">${kid.by}</a>
                <p> ${kid.text && kid.text.substring(0, length)}
                <a href="https://news.ycombinator.com/item?id=${kid.id}" target="_blank">Read More...</a>
                </div>
                `;
            }).join(`<p>      `)}
            ${story.kidData ? `<a href="https://news.ycombinator.com/item?id=${story.id}" target="_blank">All Comments</a>` : ''}
           
            `;
        });
        const htmlData = `
         <html>
            <head>
                <meta charset="utf-8">
                <meta name="HandheldFriendly" content="True">
                <meta name="MobileOptimized" content="320">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <meta name="referrer" content="no-referrer">
                <style>
                    * {
                        border:0;
                        font:inherit;
                        font-size:100%;
                        vertical-align:baseline;
                        margin:0;
                        padding:0;
                        color: black;
                        text-decoration-skip: ink;
                    }

                    h1 {
                        font-size:25px;
                        margin-top:18px;
                    }

                    h2 {
                        font-size:18px;
                    }

                    h3 {
                        font-size:12px;
                    }

                    h1 a,h2 a,h3 a {
                        text-decoration:none;
                    }
                    body {
                        font-family:'Roboto' , sans-serif;
                        font-size:14px;
                        color:#1d1313;
                        max-width:700px;
                        margin:auto;
                    }

                    .commentBox {
                        padding: 0px 8px;
                        margin-bottom: 5px;
                        background:#403c3b;
                    }

                    @media (prefers-color-scheme: dark) {
                            *, #nav h1 a {
                                color: #FDFDFD;
                            }

                            body {
                                background: #121212;
                            }

                            pre, code {
                                background-color: #262626;
                            }

                            #sub-header, .date {
                                color: #BABABA;
                            }

                            hr {
                                background: #EBEBEB;
                            }
                        }
                </style>
            </head>
            <body>
                Here is your Digest
                ${storiesInHtml.join('<p>').split('undefined').join(' ')}
            </body>
            </html>`;
        console.log(process.env.NODE_ENV);
        if (process.env.NODE_ENV === 'PROD') {
            const messageBody = JSON.stringify({ html: htmlData, type });
            const params = {
                QueueUrl: process.env.EMAIL_SENDER_URL || '', MessageBody: messageBody
            };
            await sqs.sendMessage(params).promise();
        }
        else {
            if (!fs_1.default.existsSync('testData')) {
                fs_1.default.mkdirSync('testData');
            }
            fs_1.default.writeFileSync('./testData/fbData.html', htmlData);
            console.log(JSON.stringify(stories));
        }
    }
    catch (error) {
        console.log(error);
    }
};
async function getData(url) {
    return new Promise((resolve, reject) => {
        https_1.default.get(url, (res) => {
            res.on('data', (d) => {
                resolve(JSON.parse(d.toString()));
            });
        }).on('error', (e) => {
            reject(e);
        });
    });
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZ2V0RmlyZWJhc2VEYXRhLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vc3JjL2dldEZpcmViYXNlRGF0YS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7QUFBQSxrREFBeUI7QUFDekIsc0RBQXlCO0FBQ3pCLDRDQUFtQjtBQUduQixpQkFBRyxDQUFDLE1BQU0sQ0FBQyxNQUFNLEdBQUcsWUFBWSxDQUFBO0FBQ2hDLE1BQU0sR0FBRyxHQUFHLElBQUksaUJBQUcsQ0FBQyxHQUFHLEVBQUUsQ0FBQTtBQUdaLFFBQUEsZUFBZSxHQUFHLEtBQUssRUFBRSxLQUFVLEVBQUUsRUFBRTs7SUFDaEQsSUFBSTtRQUNBLE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUE7UUFDbEIsSUFBSSxLQUFLLEdBQUcsRUFBRSxDQUFBO1FBQ2QsSUFBSSxJQUFJLEdBQUcsRUFBRSxDQUFBO1FBQ2IsSUFBSSxLQUFLLENBQUMsSUFBSSxLQUFLLEtBQUssRUFBRTtZQUN0QixLQUFLLEdBQUcsWUFBWSxDQUFBO1lBQ3BCLElBQUksR0FBRyxRQUFRLENBQUE7U0FDbEI7YUFBTSxJQUFJLEtBQUssQ0FBQyxJQUFJLEtBQUssTUFBTSxFQUFFO1lBQzlCLEtBQUssR0FBRyxhQUFhLENBQUE7WUFDckIsSUFBSSxHQUFHLFNBQVMsQ0FBQTtTQUNuQjthQUFNLElBQUksS0FBSyxDQUFDLElBQUksS0FBSyxLQUFLLEVBQUU7WUFDN0IsS0FBSyxHQUFHLFlBQVksQ0FBQTtZQUNwQixJQUFJLEdBQUcsTUFBTSxDQUFBO1NBQ2hCO2FBQU07WUFDSCxLQUFLLEdBQUcsWUFBWSxDQUFBO1lBQ3BCLElBQUksR0FBRyxhQUFhLENBQUE7U0FDdkI7UUFDRCxNQUFNLGNBQWMsR0FBRyxNQUFNLE9BQU8sQ0FBQyx5Q0FBeUMsS0FBSyxPQUFPLENBQUMsQ0FBQTtRQUMzRiw4QkFBOEI7UUFDOUIsTUFBTSxPQUFPLEdBQUcsRUFBRSxDQUFBOztZQUVsQixLQUE0QixJQUFBLEtBQUEsY0FBQSxjQUFjLENBQUMsS0FBSyxDQUFDLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQSxJQUFBO2dCQUE1QyxNQUFNLE9BQU8sV0FBQSxDQUFBO2dCQUVwQixNQUFNLFNBQVMsR0FBRyxNQUFNLE9BQU8sQ0FBQyw4Q0FBOEMsT0FBTyxvQkFBb0IsQ0FBQyxDQUFBO2dCQUMxRyxNQUFNLElBQUksR0FBRyxJQUFJLElBQUksQ0FBQyxJQUFJLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFBO2dCQUVqQyxJQUFJLENBQUMsVUFBVSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsQ0FBQTtnQkFDL0IsU0FBUyxDQUFDLElBQUksR0FBRyxJQUFJLENBQUMsV0FBVyxFQUFFLENBQUMsT0FBTyxDQUFDLEdBQUcsRUFBRSxHQUFHLENBQUMsQ0FBQyxPQUFPLENBQUMsR0FBRyxFQUFFLEVBQUUsQ0FBQyxDQUFBO2dCQUN0RSxJQUFJLFNBQVMsQ0FBQyxJQUFJLEVBQUU7b0JBQ2hCLE1BQU0sSUFBSSxHQUFHLEVBQUUsQ0FBQTs7d0JBRWYsS0FBMEIsSUFBQSxLQUFBLGNBQUEsU0FBUyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFBLElBQUE7NEJBQXpDLE1BQU0sS0FBSyxXQUFBLENBQUE7NEJBRWxCLE1BQU0sT0FBTyxHQUFHLE9BQU8sQ0FBQyw4Q0FBOEMsS0FBSyxvQkFBb0IsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRTtnQ0FDeEcsSUFBSSxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsT0FBTyxJQUFJLEdBQUcsQ0FBQyxJQUFJLEVBQUU7b0NBQ2pDLE1BQU0sT0FBTyxHQUFHLElBQUksSUFBSSxDQUFDLElBQUksRUFBRSxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUE7b0NBQ3BDLE9BQU8sQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxDQUFBO29DQUM1QixHQUFHLENBQUMsSUFBSSxHQUFHLE9BQU8sQ0FBQyxXQUFXLEVBQUUsQ0FBQyxPQUFPLENBQUMsR0FBRyxFQUFFLEdBQUcsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxHQUFHLEVBQUUsRUFBRSxDQUFDLENBQUE7b0NBQ25FLE9BQU8sR0FBRyxDQUFBO2lDQUNiOzRCQUNMLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsRUFBRSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQTs0QkFDckMsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQTt5QkFHckI7Ozs7Ozs7OztvQkFDRCxTQUFTLENBQUMsT0FBTyxHQUFHLE1BQU0sT0FBTyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBQTtpQkFDOUM7Z0JBRUQsT0FBTyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQTthQUMxQjs7Ozs7Ozs7O1FBRUQsTUFBTSxhQUFhLEdBQUcsT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsRUFBRTtZQUN0QyxNQUFNLElBQUksR0FBRyxLQUFLLENBQUMsSUFBSSxJQUFJLEVBQUUsQ0FBQTtZQUU3QixPQUFPOztrQkFFRCxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUM7Z0JBQ1QsWUFBWSxLQUFLLENBQUMsR0FBRyxxQkFBcUIsS0FBSyxDQUFDLEtBQUssTUFBTSxDQUFDLENBQUMsQ0FBQyxHQUFHLEtBQUssQ0FBQyxLQUFLLEVBQUU7O3FCQUU3RSxLQUFLLENBQUMsSUFBSTttRUFDb0MsS0FBSyxDQUFDLEVBQUUscUJBQXFCLEtBQUssQ0FBQyxFQUFFO2tCQUN0RixJQUFJOztjQUVSLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLG1CQUFtQixDQUFDLENBQUMsQ0FBQyxFQUFFO2NBQ3hDLEtBQUssQ0FBQyxPQUFPLElBQUksS0FBSyxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxHQUFRLEVBQUUsRUFBRSxDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQXNELEVBQUUsRUFBRTtnQkFDOUcsTUFBTSxNQUFNLEdBQUcsR0FBRyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLEVBQUUsR0FBRyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQTtnQkFDMUYsT0FBTzs7eUJBRU4sR0FBRyxDQUFDLElBQUk7dUVBQ3NDLEdBQUcsQ0FBQyxFQUFFLHFCQUFxQixHQUFHLENBQUMsRUFBRTtzQkFDbEYsR0FBRyxDQUFDLElBQUksSUFBSSxHQUFHLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLEVBQUUsTUFBTSxDQUFDO2dFQUNDLEdBQUcsQ0FBQyxFQUFFOztpQkFFckQsQ0FBQTtZQUNHLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUM7Y0FDMUIsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsaURBQWlELEtBQUssQ0FBQyxFQUFFLG9DQUFvQyxDQUFDLENBQUMsQ0FBQyxFQUFFOzthQUVuSCxDQUFBO1FBQUEsQ0FBQyxDQUVMLENBQUE7UUFDRCxNQUFNLFFBQVEsR0FBRzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O2tCQTJFUCxhQUFhLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDLEtBQUssQ0FBQyxXQUFXLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDOztvQkFFcEQsQ0FBQTtRQUVaLE9BQU8sQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUMsQ0FBQTtRQUNqQyxJQUFJLE9BQU8sQ0FBQyxHQUFHLENBQUMsUUFBUSxLQUFLLE1BQU0sRUFBRTtZQUNqQyxNQUFNLFdBQVcsR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLEVBQUMsSUFBSSxFQUFFLFFBQVEsRUFBRSxJQUFJLEVBQUMsQ0FBQyxDQUFBO1lBQzFELE1BQU0sTUFBTSxHQUF1QjtnQkFDL0IsUUFBUSxFQUFFLE9BQU8sQ0FBQyxHQUFHLENBQUMsZ0JBQWdCLElBQUksRUFBRSxFQUFFLFdBQVcsRUFBRSxXQUFXO2FBQ3pFLENBQUE7WUFDRCxNQUFNLEdBQUcsQ0FBQyxXQUFXLENBQUMsTUFBTSxDQUFDLENBQUMsT0FBTyxFQUFFLENBQUE7U0FDMUM7YUFBTTtZQUNILElBQUksQ0FBQyxZQUFFLENBQUMsVUFBVSxDQUFDLFVBQVUsQ0FBQyxFQUFFO2dCQUM1QixZQUFFLENBQUMsU0FBUyxDQUFDLFVBQVUsQ0FBQyxDQUFBO2FBQzNCO1lBQ0QsWUFBRSxDQUFDLGFBQWEsQ0FBQyx3QkFBd0IsRUFBRSxRQUFRLENBQUMsQ0FBQTtZQUNwRCxPQUFPLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQTtTQUN2QztLQUNKO0lBQUMsT0FBTyxLQUFLLEVBQUU7UUFDWixPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFBO0tBQ3JCO0FBQ0wsQ0FBQyxDQUFBO0FBRUQsS0FBSyxVQUFVLE9BQU8sQ0FBQyxHQUF3QztJQUMzRCxPQUFPLElBQUksT0FBTyxDQUFDLENBQUMsT0FBTyxFQUFFLE1BQU0sRUFBRSxFQUFFO1FBQ25DLGVBQUssQ0FBQyxHQUFHLENBQUMsR0FBRyxFQUFFLENBQUMsR0FBRyxFQUFFLEVBQUU7WUFFbkIsR0FBRyxDQUFDLEVBQUUsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxDQUFDLEVBQUUsRUFBRTtnQkFDakIsT0FBTyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLFFBQVEsRUFBRSxDQUFDLENBQUMsQ0FBQTtZQUNyQyxDQUFDLENBQUMsQ0FBQTtRQUVOLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxPQUFPLEVBQUUsQ0FBQyxDQUFDLEVBQUUsRUFBRTtZQUNqQixNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUE7UUFDYixDQUFDLENBQUMsQ0FBQTtJQUNOLENBQUMsQ0FBQyxDQUFBO0FBRU4sQ0FBQyJ9