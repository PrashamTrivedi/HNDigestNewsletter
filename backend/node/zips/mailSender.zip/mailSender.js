"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const aws_sdk_1 = __importDefault(require("aws-sdk"));
aws_sdk_1.default.config.region = 'ap-south-1';
const ses = new aws_sdk_1.default.SES();
exports.sendEmail = async (event) => {
    const body = JSON.parse(event.Records[0].body);
    const html = body.html;
    const type = body.type;
    const toEmail = body.to || ['prash2488@gmail.com'];
    const subjectLine = `Your Hackernews Digest for ${type}`;
    const fromEmail = 'jobs@prashamhtrivedi.in';
    const fromBase64 = Buffer.from(fromEmail).toString('base64');
    const toAddresses = toEmail;
    const htmlBody = html;
    const emailParams = {
        Destination: {
            ToAddresses: toAddresses,
        },
        Message: {
            Body: {
                Html: {
                    Charset: 'UTF-8',
                    Data: htmlBody,
                },
            },
            Subject: {
                Charset: 'UTF-8',
                Data: subjectLine,
            },
        },
        ReplyToAddresses: [fromEmail],
        Source: `=?utf-8?B?${fromBase64}?= <${fromEmail}>`,
    };
    const sesResponse = await ses.sendEmail(emailParams).promise();
    return {
        statusCode: 200
    };
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibWFpbFNlbmRlci5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uL3NyYy9tYWlsU2VuZGVyLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7O0FBQUEsc0RBQXlCO0FBQ3pCLGlCQUFHLENBQUMsTUFBTSxDQUFDLE1BQU0sR0FBRyxZQUFZLENBQUE7QUFDaEMsTUFBTSxHQUFHLEdBQUcsSUFBSSxpQkFBRyxDQUFDLEdBQUcsRUFBRSxDQUFBO0FBRVosUUFBQSxTQUFTLEdBQUcsS0FBSyxFQUFFLEtBQVUsRUFBRSxFQUFFO0lBQzFDLE1BQU0sSUFBSSxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQTtJQUM5QyxNQUFNLElBQUksR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFBO0lBQ3RCLE1BQU0sSUFBSSxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUE7SUFDdEIsTUFBTSxPQUFPLEdBQUcsSUFBSSxDQUFDLEVBQUUsSUFBSSxDQUFDLHFCQUFxQixDQUFDLENBQUE7SUFDbEQsTUFBTSxXQUFXLEdBQUcsOEJBQThCLElBQUksRUFBRSxDQUFBO0lBQ3hELE1BQU0sU0FBUyxHQUFHLHlCQUF5QixDQUFBO0lBQzNDLE1BQU0sVUFBVSxHQUFHLE1BQU0sQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxDQUFBO0lBQzVELE1BQU0sV0FBVyxHQUFHLE9BQU8sQ0FBQTtJQUUzQixNQUFNLFFBQVEsR0FBRyxJQUFJLENBQUE7SUFFckIsTUFBTSxXQUFXLEdBQUc7UUFDaEIsV0FBVyxFQUFFO1lBQ1QsV0FBVyxFQUFFLFdBQVc7U0FDM0I7UUFDRCxPQUFPLEVBQUU7WUFDTCxJQUFJLEVBQUU7Z0JBQ0YsSUFBSSxFQUFFO29CQUNGLE9BQU8sRUFBRSxPQUFPO29CQUNoQixJQUFJLEVBQUUsUUFBUTtpQkFDakI7YUFDSjtZQUNELE9BQU8sRUFBRTtnQkFDTCxPQUFPLEVBQUUsT0FBTztnQkFDaEIsSUFBSSxFQUFFLFdBQVc7YUFDcEI7U0FDSjtRQUNELGdCQUFnQixFQUFFLENBQUMsU0FBUyxDQUFDO1FBQzdCLE1BQU0sRUFBRSxhQUFhLFVBQVUsT0FBTyxTQUFTLEdBQUc7S0FDckQsQ0FBQTtJQUVELE1BQU0sV0FBVyxHQUFHLE1BQU0sR0FBRyxDQUFDLFNBQVMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxPQUFPLEVBQUUsQ0FBQTtJQUU5RCxPQUFPO1FBQ0gsVUFBVSxFQUFFLEdBQUc7S0FDbEIsQ0FBQTtBQUNMLENBQUMsQ0FBQSJ9